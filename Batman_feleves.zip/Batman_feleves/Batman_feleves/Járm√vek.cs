﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class Járművek
    {
        protected int MaxSebesseg { get; }
        protected int Ferohelyek { get; }
        protected int Lőszer { get; }
        protected int Pajzs { get; }
        public Járművek(int maxs, int ferohely, int lőszer, int pajzs)
        {
            MaxSebesseg = maxs;
            Ferohelyek = ferohely;
            Lőszer = lőszer;
            Pajzs = pajzs;
        }
    }
}
