﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class WebshopKezelo
    {
        public void Fut(ref Lista l)
        {
            Console.WriteLine("Idei költségkeret: ");
            int ktgkeret = int.Parse(Console.ReadLine());
            while (true)
            {
                Console.Clear();
                Console.BackgroundColor = ConsoleColor.DarkYellow;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("Wayne shop");
                Console.ResetColor();
                l.Megjelenites();
                Console.WriteLine("\nHozzáad/Törlés/Ajánlat/Kilépés");
                string milegyen = Console.ReadLine();
                if (milegyen == "Hozzáad")
                {
                    l.Hozzaad();
                }
                else if (milegyen == "Törlés")
                {
                    Console.WriteLine("Melyik ID?");
                    l.Torol(int.Parse(Console.ReadLine()));
                    Console.Clear();
                    l.Megjelenites();
                }
                else if (milegyen == "Kilépés")
                {
                    Environment.Exit(0);
                }
                else if(milegyen == "Ajánlat")
                {
                    Console.Clear();
                    Console.WriteLine("Optimális ajánlat:");
                    BinarisKeresofa a = l.Moho(ktgkeret);
                    Console.WriteLine(a.Inorder());
                    Console.ReadLine();
                }
                
            }
            
        }
    }
}
