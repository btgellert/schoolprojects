﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class Batarang : KéziEszközök
    {
        public Batarang(int ID, int fajdalom, int hasznos, int ktg) : base(ID, fajdalom, hasznos, ktg)
        {
        }
    }
}
