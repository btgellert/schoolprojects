﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class Batmobil : Járművek
    {
        bool GépfegyverÜzemképes;
        int DízelMennyiség;
        public Batmobil(int maxs, int ferohely, int loszer, int pajzs, int dízelMennyiség) : base(maxs, ferohely, loszer, pajzs)
        {
            GépfegyverÜzemképes = true;
            DízelMennyiség = dízelMennyiség;
        }
    }
}
