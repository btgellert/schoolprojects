﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    delegate void ListaBejaro(KéziEszközök k);
    internal class Lista
    {
        public KéziEszközök fej;
        public int Meret=0;
        public BinarisKeresofa Moho(int c)
        {
            int seged = c;
            List<KéziEszközök> a = new List<KéziEszközök>();

            KéziEszközök p = fej;
            while (c > 0 && p != null)
            {
                if (p.Költség <= c)
                {
                    a.Add(p);
                    c -= p.Költség;
                }
                p = p.Következő;
            }
            if (seged == c)
            {
                throw new CsóróBatmanException();
            }
            BinarisKeresofa b = new BinarisKeresofa();

            foreach (var item in a)
            {
                b.Beszuras(item, item.Költség);
            }
            return b;
        }

        public void ElemBeszuras(KéziEszközök eszkoz)
        {
            KéziEszközök uj = new KéziEszközök();
            uj = eszkoz;
            KéziEszközök p = fej;
            KéziEszközök e = null;
            while (p != null && p.Hasznosság/p.Költség >= eszkoz.Hasznosság/eszkoz.Költség)
            {
                if (p.ID == uj.ID)
                {
                    throw new UgyanolyanException();
                }
                e = p;
                p = p.Következő;
            }
            Meret++;
            if (e == null)
            {
                uj.Következő = fej;
                fej = uj;
            }
            else
            {
                uj.Következő = p;
                e.Következő = uj;
            }
        }
        public ListaBejaro bejar;
        public void Megjelenites()
        {
            KéziEszközök p = fej;
            while (p != null)
            {
                bejar(p);
                p = p.Következő;
            }
        }
        public void Hozzaad()
        {
            Console.WriteLine("ID:, Fájdalom:, Hasznosság:, Költség:, Fajta:");
            int id = int.Parse(Console.ReadLine());
            int faj = int.Parse(Console.ReadLine());
            int hasz = int.Parse(Console.ReadLine());
            int ktg = int.Parse(Console.ReadLine());
            string fajta = Console.ReadLine();
            Console.Clear();
            if (fajta == "Batarang")
            {
                ElemBeszuras(new Batarang(id, faj, hasz, ktg));
            }
            else if(fajta == "RobbanóGél")
            {
                ElemBeszuras(new RobbanóGél(id, faj, hasz, ktg));
            }
            else if (fajta == "Ejtőernyő")
            {
                ElemBeszuras(new Ejtőernyő(id, faj, hasz, ktg));
            }
            else
            {
                throw new NincsIlyenEszközException();
            }
        }
        public void Torol(int id)
        {
            KéziEszközök p = fej;
            KéziEszközök e = null;
            while (p != null && p.ID != id)
            {
                e = p;
                p = p.Következő;
            }
            
            if (p != null)
            {
                if (e == null)
                {
                    fej = p.Következő;
                }
                else
                {
                    e.Következő = p.Következő;
                }
            }
            else
            {
                throw new NincsIlyenEszközException();
            }
            Meret--;
        }
    }
}
