﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class Batcopter : Járművek
    {
        int KerozinMennyiseg;
        public Batcopter(int maxs, int ferohely, int lőszer, int pajzs, int kerozinMennyiseg) : base(maxs, ferohely, lőszer, pajzs)
        {
            KerozinMennyiseg = kerozinMennyiseg;
        }
    }
}
