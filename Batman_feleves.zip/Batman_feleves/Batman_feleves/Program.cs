﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class Program
    {
        static void Kiiro(KéziEszközök k)
        {
            Console.WriteLine(k.ID+". "+k.ToString().Split('.')[1]+"\t fájdalom: "+k.FajdalomSkala+", hasznosság: "+k.Hasznosság+ ", költésg: "+k.Költség);
        }
        static void Main(string[] args)
        {
            
            Batarang b = new Batarang(1, 4, 10, 20);
            Ejtőernyő e = new Ejtőernyő(2, 1, 3, 5);
            RobbanóGél r = new RobbanóGél(3, 10, 10, 100);
            Batarang g = new Batarang(5, 4, 10, 3);
            Ejtőernyő m = new Ejtőernyő(4, 1, 3, 50);
            RobbanóGél c = new RobbanóGél(6, 10, 100, 80);
            Lista l = new Lista();
            l.ElemBeszuras(r);
            l.ElemBeszuras(b);
            l.ElemBeszuras(e);
            l.ElemBeszuras(g);
            l.ElemBeszuras(m);
            l.ElemBeszuras(c);

            l.bejar += Kiiro;
            WebshopKezelo w = new WebshopKezelo();
            w.Fut(ref l);

            
            ;
        }
    }
}
