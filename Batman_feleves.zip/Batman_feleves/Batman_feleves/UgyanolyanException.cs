﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class UgyanolyanException : Exception
    {
        public UgyanolyanException() : base("Ilyen eszköz már van!")
        {
            
        }
    }
}
