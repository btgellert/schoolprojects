﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class KéziEszközök
    {
        public int ID { get; }
        public int FajdalomSkala { get; }
        public int Hasznosság { get; }
        public int Költség { get; }
        public KéziEszközök Következő { get; set; }
        public KéziEszközök(int ID, int fajdalom, int hasznos, int ktg)
        {
            this.ID = ID;
            FajdalomSkala = fajdalom;
            Hasznosság = hasznos;
            Költség = ktg;
        }
        public KéziEszközök()
        {
            
        }

    }
}
