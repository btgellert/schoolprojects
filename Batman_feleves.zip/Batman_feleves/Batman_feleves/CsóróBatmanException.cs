﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class CsóróBatmanException : Exception
    {
        public CsóróBatmanException() : base("Nincs elég pénze a vállalatnak.")
        {
            
        }
    }
}
