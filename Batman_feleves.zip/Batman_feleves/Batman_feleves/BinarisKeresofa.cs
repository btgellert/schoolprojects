﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class BinarisKeresofa
    {
        class Node
        {
            public KéziEszközök k;
            public int kulcs;
            public Node Left;
            public Node Right;
        }
        private Node gyoker;

        public string Inorder()
        {
            if (gyoker == null)
            {
                return "";
            }
            else
            {
                return Inorder(gyoker);
            }
        }
        string Inorder(Node p)
        {
            string a = "";
            if (p!=null)
            {
                string x = Inorder(p.Left);
                string z = (p.k.ID + ". " + p.k.ToString().Split('.')[1] + "\t fájdalom: " + p.k.FajdalomSkala + ", hasznosság: " + p.k.Hasznosság + ", költésg: " + p.k.Költség) +"\n";
                string y = Inorder(p.Right);
                a += x + y + z;
            }
            return a;
        }
        public void Beszuras(KéziEszközök k, int kulcs)
        {
            _Beszuras(ref gyoker, k, kulcs);
        }
        private void _Beszuras(ref Node p, KéziEszközök k, int kulcs)
        {
            if (p==null)
            {
                p = new Node();
                p.k = k;
                p.kulcs = kulcs;
            }
            else
            {
                if (p.kulcs < kulcs)
                {
                    _Beszuras(ref p.Right, k, kulcs);
                }
                else if(p.kulcs > kulcs)
                {
                    _Beszuras(ref p.Left, k, kulcs);
                }
                else
                {
                    throw new ArgumentException("ugyanolyan kulcs");
                }
            }
        }

    }
}
