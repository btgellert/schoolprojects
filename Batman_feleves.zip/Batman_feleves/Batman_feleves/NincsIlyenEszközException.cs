﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batman_feleves
{
    internal class NincsIlyenEszközException : Exception
    {
        public NincsIlyenEszközException() : base("Nem létezik ilyen eszköz")
        {
            
        }
    }
}
