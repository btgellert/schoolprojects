﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using SZTF_felevesuj;

namespace SZTF_Feleves
{
    internal class Segitseg
    {
        public void Felezo(string nehezseg, string kerdes, string helyes, string[] lehetosegek, Jatekos jatekos)
        {
            Console.Clear();
            Console.WriteLine("\n\n\t !Felező segítség!");
            Console.WriteLine("Legyen ön is milliomos!\t\t"+jatekos.pont+"pontod van most.");
            Random r = new Random();
            bool nemhelyes = false;
            string masikvalasz = "";
            while (!nemhelyes)
            {
                string lehetoseg = lehetosegek[r.Next(0, lehetosegek.Length)];
                if (lehetoseg != helyes)
                {
                    masikvalasz = lehetoseg;
                    nemhelyes = true;
                }
            }
            string[] ered = { helyes, masikvalasz };
            int mutat = r.Next(0, 2);
            Console.WriteLine(nehezseg+". "+kerdes+"\n" +" | " + ered[mutat] + " | " + ered[1-mutat] + " | ");
            Console.Write("Válasz: ");
        }
        public void TelefonosSegitseg(string nehezseg, string kerdes, string helyes, Jatekos jatekos)
        {
            Console.Clear();
            Console.WriteLine("\n\n\t !Telefonos segítség!");
            Console.WriteLine("Legyen ön is milliomos!\t\t"+jatekos.pont+"pontod van most.");
            Console.WriteLine(nehezseg + ". " + kerdes + "\n" + " | " + helyes + " | ");
            Console.Write("Válasz: ");
        }
        public void KozonsegSegitseg(string nehezseg, string kerdes, string a, string b, string c, string d, string helyes, int m, Jatekos jatekos)
        {
            Console.Clear();
            Random r = new Random();
            int helyesarany = 15 - m;
            int aarany = r.Next(0, m);
            int barany = r.Next(0, m - aarany);
            int carany = r.Next(0, m - barany);
            int sum = helyesarany + aarany + barany + carany;
            string[] tomb = { a, b, c, d };
            string[] seg = new string[tomb.Length - 1];
            int segind = 0;
            for (int i = 0; i < tomb.Length; i++)
            {
                if (helyes != tomb[i])
                {
                    seg[segind] = tomb[i];
                    segind++;
                }
            }
            Console.WriteLine("\n\n\t !Közönség segítség!");
            Console.WriteLine("Legyen ön is milliomos!\t\t"+jatekos.pont+" pontod van most.");
            Console.WriteLine(nehezseg + ". " + kerdes + "\n" + " | " + seg[2] + " " + Math.Round((double)aarany / (double)sum * 100,0) + "%" + " | " + " | " + helyes + " " + Math.Round((double)helyesarany / (double)sum * 100,0) + "%" + " | " + "\n" + " | " + seg[1] + " " + Math.Round((double)barany / (double)sum * 100,0) + "%" + " | " + " | " + seg[0] + " " + Math.Round((double)carany / (double)sum * 100,0) + "%" + " | ");
            Console.Write("Válasz: ");

        }
    }
}
