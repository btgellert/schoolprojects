﻿using _1025;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using SZTF_Feleves;

namespace SZTF_felevesuj
{
    internal class Jatek
    {
        public void Jatek2(Kerdes[] kerdesek)
        {
            Jatekos jatekos = new Jatekos();
            Console.WriteLine("Ki játszik?");
            jatekos.nev = Console.ReadLine();
            Segitseg segitseg = new Segitseg();
            jatekos.pont = 0;
            int checkpoint = 0;
            bool telefon = true;
            bool kozonseg = true;
            bool felezo = true;
            int j = 0;
            while (j < kerdesek.Length)
            {
                if (j == 5)
                {
                    checkpoint = 2500;
                }
                else if (j == 10)
                {
                    checkpoint = 5000;
                }
                Console.Clear();
                Console.WriteLine("\n\n");
                Console.WriteLine("Legyen ön is milliomos! \t\t " + jatekos.pont + " pontod van most.");
                if (telefon)
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write("| Telefon |");
                    Console.ResetColor();
                }
                if (kozonseg)
                {
                    Console.BackgroundColor = ConsoleColor.DarkBlue;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("| Kozonseg |");
                    Console.ResetColor();
                }
                if (felezo)
                {
                    Console.BackgroundColor = ConsoleColor.DarkYellow;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write("| Felezo |");
                    Console.ResetColor();
                }
                Console.WriteLine();
                Console.BackgroundColor = ConsoleColor.Yellow;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine(kerdesek[j].nehezseg + ". " + kerdesek[j].kerdes + "\n"+ " | " + kerdesek[j].valaszA + " | " + " | " + kerdesek[j].valaszB + " | " + "\n" + " | " + kerdesek[j].valaszC + " | " + " | " + kerdesek[j].valaszD + " | ");
                Console.ResetColor();
                Console.Write("Válasz: ");
                string valasza = Console.ReadLine();

                if (valasza == "Felezo" && felezo)
                {
                    felezo = false;
                    string[] valaszok = { kerdesek[j].valaszA, kerdesek[j].valaszB, kerdesek[j].valaszC, kerdesek[j].valaszD };
                    segitseg.Felezo(kerdesek[j].nehezseg, kerdesek[j].kerdes, kerdesek[j].helyesvalasz, valaszok, jatekos);
                    SegitsegValasz(ref kerdesek, ref j, ref jatekos, ref checkpoint);
                }
                else if (valasza == "Telefon" && telefon)
                {
                    telefon = false;
                    segitseg.TelefonosSegitseg(kerdesek[j].nehezseg, kerdesek[j].kerdes, kerdesek[j].helyesvalasz, jatekos);
                    SegitsegValasz(ref kerdesek, ref j, ref jatekos, ref checkpoint);
                }
                else if (valasza == "Kozonseg" && kozonseg)
                {
                    kozonseg = false;
                    segitseg.KozonsegSegitseg(kerdesek[j].nehezseg, kerdesek[j].kerdes, kerdesek[j].valaszA, kerdesek[j].valaszB, kerdesek[j].valaszC, kerdesek[j].valaszD, kerdesek[j].helyesvalasz, j, jatekos);
                    SegitsegValasz(ref kerdesek, ref j, ref jatekos, ref checkpoint);
                }
                else if (valasza == "Menu")
                {
                    Menu(jatekos);
                }
                else if (valasza != kerdesek[j].helyesvalasz)
                {
                    jatekos.pont = 0;
                    j = kerdesek.Length + 1;
                    Console.Clear();
                    Console.WriteLine("Sajnos vesztettél.");
                    if (checkpoint != 0)
                    {
                        jatekos.pont = checkpoint;
                    }
                    Console.WriteLine(jatekos.pont + " pontot szereztél!");
                    File.AppendAllText("Rangsor.txt", jatekos.nev + "," + DateTime.Now.ToString("yyyy/MM/dd") + "," + jatekos.pont + " pont" + ";");
                    Console.ReadLine();
                    Menu(jatekos);
                }
                else
                {
                    jatekos.Pontnovel();
                    Console.WriteLine("Helyes Válasz!\nAz új pontod: " +jatekos.pont+ "\nFolytatod? (y/n)");
                    if (Console.ReadLine() == "y")
                    {
                        j++;
                    }
                    else
                    {
                        j = kerdesek.Length + 1;
                        Console.WriteLine("Gratulálok! " + jatekos.pont + " pontot szereztél!");
                        File.AppendAllText("Rangsor.txt", jatekos.nev + "," + DateTime.Now.ToString("yyyy/MM/dd") + "," + jatekos.pont + " pont" + ";");
                        Console.ReadLine();
                        Menu(jatekos);
                    }
                }
                if (j == kerdesek.Length)
                {
                    Console.Clear();
                    Console.WriteLine("Nyertél! " + jatekos.pont + " pontod van.");
                    File.AppendAllText("Rangsor.txt", jatekos.nev + "," + DateTime.Now.ToString("yyyy/MM/dd") + "," + jatekos.pont + " pont" + ";");
                    Console.ReadLine();
                    Menu(jatekos);
                }
            }
        }
        public void Menu(Jatekos jatekos)
        {
            Console.Clear();
            Console.WriteLine("Új játék");
            Console.WriteLine("Ranglista");
            Console.WriteLine("Exit");
            string valasz = Console.ReadLine();
            if (valasz == "Exit")
            {
                Environment.Exit(0);
            }
            else if (valasz == "Ranglista")
            {
                Rangsor("Rangsor.txt", jatekos);
            }
            else if (valasz == "Új játék")
            {

                Console.WriteLine("Helyezze a csv-re alakított fájlt (Fájl->Exportálás->Fájltípus módosítása->CSV) a debug mappába, majd adja meg a file nevét!\nHa " + "Teszt.csv" + "-t ír be, előre feltöltött kérdésekkel játszhat.");
                string[] tomb = File.ReadAllLines(Console.ReadLine(), Encoding.Default);
                Kerdes[] kerdesek = new Kerdes[tomb.Length];
                for (int i = 0; i < kerdesek.Length; i++)
                {
                    string[] kerdes = tomb[i].Split(';');
                    kerdesek[i] = new Kerdes(kerdes);
                    Console.WriteLine(kerdesek[i].nehezseg + " " + kerdesek[i].kerdes);
                }
                Console.Clear();
                Jatek2(kerdesek);
            }
            else
            {
                Menu(jatekos);
            }
        }
        public void Rangsor(string path, Jatekos jatekos)
        {
            Console.Clear();
            string[] szoveg = File.ReadAllText(path).Split(';');
            string[,] szerkezet = new string[szoveg.Length - 1, 3];
            for (int i = 0; i < szoveg.Length - 1; i++)
            {
                string[] seg = szoveg[i].Split(',');
                for (int j = 0; j < 3; j++)
                {
                    szerkezet[i, j] = seg[j];
                }
            }
            for (int i = 0; i < szerkezet.GetLength(0); i++)
            {
                for (int j = i; j < szerkezet.GetLength(0); j++)
                {
                    if (int.Parse(szerkezet[i, 2].Split(' ')[0]) < int.Parse(szerkezet[j, 2].Split(' ')[0]))
                    {
                        string tmp1 = szerkezet[i, 0];
                        szerkezet[i, 0] = szerkezet[j, 0];
                        szerkezet[j, 0] = tmp1;
                        string tmp2 = szerkezet[i, 1];
                        szerkezet[i, 1] = szerkezet[j, 1];
                        szerkezet[j, 1] = tmp2;
                        string tmp3 = szerkezet[i, 2];
                        szerkezet[i, 2] = szerkezet[j, 2];
                        szerkezet[j, 2] = tmp3;
                    }
                }
            }
            for (int i = 0; i < szerkezet.GetLength(0); i++)
            {
                for (int j = 0; j < szerkezet.GetLength(1); j++)
                {
                    Console.Write(szerkezet[i, j] + "\t");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
            Menu(jatekos);
        }
        public void SegitsegValasz(ref Kerdes[] kerdesek, ref int j, ref Jatekos jatekos, ref int checkpoint)
        {
            string valasza = Console.ReadLine();
            if (valasza != kerdesek[j].helyesvalasz)
            {
                jatekos.pont = 0;
                j = kerdesek.Length + 1;
                Console.Clear();
                Console.WriteLine("Sajnos vesztettél.");
                if (checkpoint != 0)
                {
                    jatekos.pont = checkpoint;
                }
                Console.WriteLine(jatekos.pont + " pontot szereztél!");
                File.AppendAllText("Rangsor.txt", jatekos.nev + "," + DateTime.Now.ToString("yyyy/MM/dd") + "," + jatekos.pont + " pont" + ";");
                Console.ReadLine();
                Menu(jatekos);
            }
            else
            {
                jatekos.Pontnovel();
                Console.WriteLine("Helyes Válasz!\nAz új pontod: "+jatekos.pont+ "\nFolytatod? (y/n)");
                if (Console.ReadLine() == "y")
                {
                    j++;
                }
                else
                {
                    j = kerdesek.Length + 1;
                    Console.WriteLine("Gratulálok! " + jatekos.pont + " pontot szereztél!");
                    File.AppendAllText("Rangsor.txt", jatekos.nev + "," + DateTime.Now.ToString("yyyy/MM/dd") + "," + jatekos.pont + " pont" + ";");
                    Console.ReadLine();
                    Menu(jatekos);
                }
            }
        }
        
    }
}
