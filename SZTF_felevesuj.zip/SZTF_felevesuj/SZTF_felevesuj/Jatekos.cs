﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZTF_felevesuj
{
    internal class Jatekos
    {
        public string nev;
        public int pont;
        public void Pontnovel()
        {
            pont += 500;
        }
    }
}
