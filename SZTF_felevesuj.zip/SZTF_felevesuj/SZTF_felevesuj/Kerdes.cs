﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _1025
{
    internal class Kerdes
    {
        public string nehezseg;
        public string kerdes;
        public string valaszA;
        public string valaszB;
        public string valaszC;
        public string valaszD;
        public string helyesvalasz;

        public Kerdes(string[] kerdes)
        {

            nehezseg = kerdes[0];
            this.kerdes = kerdes[1];
            valaszA = kerdes[2];
            valaszB = kerdes[3];
            valaszC = kerdes[4];
            valaszD = kerdes[5];
            helyesvalasz = kerdes[6];

        }
    }
}
