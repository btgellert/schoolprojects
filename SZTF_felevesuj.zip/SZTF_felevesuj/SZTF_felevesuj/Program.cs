﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SZTF_Feleves;
using SZTF_felevesuj;

namespace _1025
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Feltöltés
            Console.WriteLine("Helyezze a csv-re alakított fájlt (Fájl->Exportálás->Fájltípus módosítása->CSV) a debug mappába, majd adja meg a file nevét!\nHa "+"Teszt.csv"+"-t ír be, előre feltöltött kérdésekkel játszhat.");
            string[] tombkezd = File.ReadAllLines(Console.ReadLine(), Encoding.Default);
            int counter = 0;
            for (int i = 0; i < tombkezd.Length; i++)
            {
                bool rossz = false;
                string[] seg = tombkezd[i].Split(';');
                int j = 0;
                while (j < seg.Length - 1 && !rossz)
                {
                    if (seg[j].Length == 0)
                    {
                        rossz = true;
                        counter++;
                    }
                    j++;
                }
            }
            string[] tomb = new string[tombkezd.Length - counter];
            int db = 0;
            for (int i = 0; i < tombkezd.Length; i++)
            {
                bool rossz = false;
                string[] seg = tombkezd[i].Split(';');
                int j = 0;
                while (j < seg.Length - 1 && !rossz)
                {
                    if (seg[j].Length == 0)
                    {
                        rossz = true;
                    }
                    j++;
                }
                if (!rossz)
                {
                    tomb[db] = tombkezd[i];
                    db++;
                }
            }
            Kerdes[] kerdesek = new Kerdes[tomb.Length];
            for (int i = 0; i < kerdesek.Length; i++)
            {
                string[] kerdes = tomb[i].Split(';');
                kerdesek[i] = new Kerdes(kerdes);
                Console.WriteLine(kerdesek[i].nehezseg + " " + kerdesek[i].kerdes);
            }
            Console.Clear();
            #endregion
            Jatek jatek = new Jatek();
            jatek.Jatek2(kerdesek);
        }
    }
}

